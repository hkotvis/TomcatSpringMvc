package midtermMvc;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
public class HomeController {

    @RequestMapping("/")
    public String showHomePage() {
        return "home-page";
    }
    @RequestMapping("/home")
    public String backToHomePage() {
        return "home-page";
    }

    @RequestMapping("/createProfile")
    public String createProfile(Model model) {
        Profile theProfile = new Profile();
        model.addAttribute("bindingAvatar", theProfile);
        return "create-profile";
    }
    @RequestMapping("/showProfile")
    public String showProfile(HttpServletRequest request, @ModelAttribute("bindingAvatar") Profile theProfile, Model model){

        System.out.println(theProfile.getAvatar());
        System.out.println(theProfile.getFirstName());

        return "show-profile";
    }

}